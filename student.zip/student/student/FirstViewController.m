//
//  FirstViewController.m
//  student
//
//  Created by 房彤 on 2020/7/28.
//  Copyright © 2020 房彤. All rights reserved.
//

#import "FirstViewController.h"
#import "StuTableViewCell.h"

@interface FirstViewController ()

@property NSMutableArray *name;
@property NSMutableArray *class;
@property NSMutableArray *num;
@property NSMutableArray *score;

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bz.jpg"]];
    
    
    
    
    //初始信息
    self.name = [[NSMutableArray alloc] init];
    [self.name addObject:@"小红"];
    [self.name addObject:@"小橙"];
    [self.name addObject:@"小黄"];
    [self.class addObject:@"1班"];
    [self.class addObject:@"1班"];
    [self.class addObject:@"3班"];
    [self.num addObject:@"1001"];
    [self.num addObject:@"1003"];
    [self.num addObject:@"1006"];
    [self.score addObject:@"100"];
    [self.score addObject:@"98"];
    [self.score addObject:@"78"];
    
    //tableView
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(20, 70, 374, 370) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
   // [self.tableView registerClass:[StuTableViewCell class] forCellReuseIdentifier:@"ft"];
    [self.view addSubview:self.tableView];
    
    //addButton
    self.addButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.addButton.frame = CGRectMake(60, 470, 90, 37);
    self.addButton.layer.cornerRadius = 7;
    self.addButton.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.addButton.layer setMasksToBounds:YES];
    self.addButton.layer.borderWidth = 1.3;
    self.addButton.titleLabel.font = [UIFont systemFontOfSize:17];
    self.addButton.tintColor = [UIColor whiteColor];
    
    
    [self.addButton setTitle:@"增加" forState:UIControlStateNormal];
    [self.addButton addTarget:self action:@selector(pressAdd) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.addButton];
    
    //deleteButton
    self.deleteButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.deleteButton.frame = CGRectMake(264, 470, 90, 37);
    self.deleteButton.layer.cornerRadius = 7;
    self.deleteButton.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.deleteButton.layer setMasksToBounds:YES];
    self.deleteButton.layer.borderWidth = 1.3;
    self.deleteButton.titleLabel.font = [UIFont systemFontOfSize:17];
    self.deleteButton.tintColor = [UIColor whiteColor];
    
    [self.deleteButton setTitle:@"删除" forState:UIControlStateNormal];
    [self.deleteButton addTarget:self action:@selector(pressDelete) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.deleteButton];
    
    //modifyButton
    self.modifyButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.modifyButton.frame = CGRectMake(60, 525, 90, 37);
    self.modifyButton.layer.cornerRadius = 7;
    self.modifyButton.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.modifyButton.layer setMasksToBounds:YES];
    self.modifyButton.layer.borderWidth = 1.3;
    self.modifyButton.titleLabel.font = [UIFont systemFontOfSize:17];
    self.modifyButton.tintColor = [UIColor whiteColor];
    
    [self.modifyButton setTitle:@"修改" forState:UIControlStateNormal];
    [self.modifyButton addTarget:self action:@selector(pressModify) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.modifyButton];
    
    
    //searchButton
    self.searchButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.searchButton.frame =CGRectMake(264, 525, 90, 37);
    self.searchButton.layer.cornerRadius = 7;
    self.searchButton.layer.borderWidth = 1.3;
    [self.searchButton.layer setMasksToBounds:YES];
    self.searchButton.layer.borderColor = [UIColor whiteColor].CGColor;
    self.searchButton.titleLabel.font = [UIFont systemFontOfSize:17];
    self.searchButton.tintColor= [UIColor whiteColor];
    
    [self.searchButton setTitle:@"查询" forState:UIControlStateNormal];
    [self.searchButton addTarget:self action:@selector(pressSearch) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.searchButton];
    
    //退出
    self.quitButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.quitButton.frame = CGRectMake(150, 585, 115, 40);
    self.quitButton.layer.cornerRadius = 7;
    self.quitButton.layer.borderWidth = 1.3;
   // self.quitButton.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.quitButton.layer setMasksToBounds:YES];
    self.quitButton.titleLabel.font = [UIFont systemFontOfSize:18];
    self.quitButton.tintColor = [UIColor whiteColor];
    self.quitButton.backgroundColor = [UIColor colorWithRed:0.8 green:0.1 blue:0.1 alpha:1];
    
    [self.quitButton setTitle:@"退出" forState:UIControlStateNormal];
    [self.quitButton addTarget:self action:@selector(pressQuit) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.quitButton];
    
}

- (void)pressAdd {
    
    
    
}

- (void)pressDelete {
    
}


- (void)pressModify {
    
}

- (void)pressSearch {
    
}

- (void)pressQuit {
    
}
 
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
   // NSLog(@"%ld", [self.name count]);
    //return [self.name count];
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    StuTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ft" forIndexPath:indexPath];
    if(cell == nil) {
        cell = [[StuTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ft"];
    }
   
    cell.nameLabel.text = @"小红";
    cell.classLabel.text = @"1";
    cell.numLabel.text = @"1001";
    cell.scoreLabel.text = @"12";

    //cell.nameLabel.text = self.name[indexPath.row];
    //cell.classLabel.text = self.class[indexPath.row];
    //cell.numLabel.text = self.num[indexPath.row];
    //cell.scoreLabel.text = self.score[indexPath.row];
    return cell;
}





@end
