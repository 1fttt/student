//
//  StuTableViewCell.h
//  student
//
//  Created by 房彤 on 2020/7/29.
//  Copyright © 2020 房彤. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface StuTableViewCell : UITableViewCell

@property UILabel *nameLabel;
@property UILabel *classLabel;
@property UILabel *numLabel;
@property UILabel *scoreLabel;

@end

NS_ASSUME_NONNULL_END
