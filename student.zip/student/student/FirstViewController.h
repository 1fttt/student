//
//  FirstViewController.h
//  student
//
//  Created by 房彤 on 2020/7/28.
//  Copyright © 2020 房彤. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Student.h"

NS_ASSUME_NONNULL_BEGIN

//只是为了在interface中引用这个类，把这个类作为一个类型来用的
//@class Student;

@interface FirstViewController : UIViewController

<UITableViewDelegate, UITableViewDataSource>

@property UITableView *tableView;
@property UIButton *addButton;
@property UIButton *deleteButton;
@property UIButton *modifyButton;
@property UIButton *searchButton;
@property UIButton *quitButton;
@end

NS_ASSUME_NONNULL_END
