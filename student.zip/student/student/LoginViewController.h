//
//  LoginViewController.h
//  student
//
//  Created by 房彤 on 2020/7/28.
//  Copyright © 2020 房彤. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : UIViewController
@property UITextField *userTextField;
@property UITextField *passTextField;
@property UIButton *loginButton;
@property UIButton *registerButton;
@end

NS_ASSUME_NONNULL_END
